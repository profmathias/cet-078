public class Cliente extends Pessoa
{
    
}
