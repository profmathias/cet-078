public class Pessoa
{
    protected String nome;
    private String email;
    private String cpf;
    private String endereco;
    
               
    public void setCpf(String cpf) {
        //código para checar se o cpf é válido...
        this.cpf = cpf;
    }
}
