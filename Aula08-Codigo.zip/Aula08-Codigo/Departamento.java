public class Departamento
{
    private String nome;
    
    public void setNome(String n) {
        nome = n;
    }
}
