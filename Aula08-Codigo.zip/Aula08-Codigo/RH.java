import java.util.ArrayList;


public class RH
{
    private ArrayList<Funcionario> funcionarios = new ArrayList<Funcionario>();
    
    //menu()
    //contratar()
    //demitir()
    //relatorio()
}
